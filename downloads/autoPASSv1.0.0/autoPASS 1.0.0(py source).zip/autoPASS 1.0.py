from os import system, name
import random
import time

def clear():
    if name == 'nt':
        _ = system('cls')

adjectives = ['Sleepy','Great','Fluffy','Sleepy','Brave','Clumsy','Orange','Green','Stupid','Small','Huge','Funny','Shocked','Dumb','Genius','Cubic','Enormous','Big','Bad','Terrifying','Populous']

nouns = ['apple','melon','person','geek','cat','dinosaur','nerd','computer','hippo','rhino','shoe','elephant','Wolf','pig','lemon','laptop','videogame','machine','country','ghost','town']

options = ['Generate Now!','What makes a good password?','About autoPASS','Exit!']

special_char =[':','?','!','(',')','='] 

def menu():
    print("  == autoPASS software version 1.0 == ")
    print("  ==   copyright XTui, 2020-2021   == ")
    print("  ----------------------------------- ")
    for counter in range(len(options)):
      print("[",counter+1,"]",options[counter])
    print("  =================================== ")
    option = input("Please select option(1/2/3/4): ")
    if option == "1":
        clear()
        generate()
    elif option == '2':
        clear()
        learn()
    elif option == '3':
        clear()
        about()
    elif option == '4':
        exit()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        menu()
    

def learn():
    print(" == What makes a good password? == (page: 1)")
    print(" A good password requires 4 of these points:")
    print(" 1. Uppercase letters (eg: B)")
    print(" 2. lowercase letters (eg: b)")
    print(" 3. Numbers (eg: 1)")
    print(" 4. Special characters (eg: !)")
    choice = input("Please select option(1: Next page/2: quit): ")
    if choice == '1':
        clear()
        learn2()
    elif choice == '2':
        clear()
        menu()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        learn()

def learn2():
    print(" == What makes a good password? == (page: 2)")
    print(" And, if we got all of those variations, we created the best password combination!")
    print(" Such as this: X5j13$#eCM1cG@Kdc. or this: E7r9t8@Q#h%Hy+M.")
    print(" Passwords such as the one up here has all the variations needed to create a strong,")
    print(" Uncrackable password.")
    print(" But, there's a downside to even strong passwords like that,")
    choice = input("Please select option(1: Next page/2: Previous page/3: quit): ")
    if choice == '1':
        clear()
        learn3()
    elif choice == '2':
        clear()
        learn()
    elif choice == '3':
        clear()
        menu()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        learn2()

def learn3():
    print(" == What makes a good password? == (page: 3)")
    print(" The problem is: passwords like those are really hard to remember.")
    print(" And if you forgot those passwords, now you're locked out.")
    print(" But, there's a better option!")
    choice = input("Please select option(1: Next page/2: Previous page/3: quit): ")
    if choice == '1':
        clear()
        learn4()
    elif choice == '2':
        clear()
        learn2()
    elif choice == '3':
        clear()
        menu()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        learn3()

def learn4():
    print(" == What makes a good password? == (page: 3)")
    print(" There is also a better password formula!")
    print(" Which is: Adjective + Noun + Number + Special characters")
    print(" eg: Smallcow92818?, Smartperson3234!")
    print(" They also have the criteria of a strong password!")
    print(" They are much easier to remember and are as secure as the other kind.")
    print(" And, autoPASS Software generates these passwords for you to use for all of your accounts!")
    print(" Thank you for using autoPASS!") 
    choice = input("Please select option(1: Previous page/2: quit): ")
    if choice == '1':
        clear()
        learn3()
    elif choice == '2':
        clear()
        menu()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        learn4()

def generate():
    global adjectives,nouns,special_char
    print('==',"GENERATOR",'==')
    print("Generating Password...")
    adjective = random.choice(adjectives)
    noun = random.choice(nouns)
    number = random.randrange(0,50000)
    spcchr = random.choice(special_char)
    Password = (adjective + noun + str(number) + spcchr)
    time.sleep(random.randint(1,3))
    clear()
    print("==","GENERATOR","==")
    print("Password generated!")
    print("Here is your Password: ", Password)
    choice = input("please select option(1: Create another password/2: Go back to menu): ")
    if choice == '1':
        clear()
        generate()
    elif choice == '2':
        clear()
        menu()
    else:
        clear()
        print(" ERROR ")
        print(" Choice not availble. press enter to retry ")
        input()
        clear()
        generate()

def about():
    print(" ==       About       ==")
    print(" == autoPASS software ==")
    print("-------------------------")
    print("Credit goes to: ")
    print("XTui - Creating this program")
    print("----------------------------")
    print("autoPASS is written in Python 3")
    print("autoPASS is converted into .exe using auto-py-to-exe")
    print("----------------------------")
    print("Copyright 2020-2021 XTui    ")
    print('============================')
    input(" Press enter to go back to menu: ")
    clear()
    menu()
                
#main
menu()
    
    
